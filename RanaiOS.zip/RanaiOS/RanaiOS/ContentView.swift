//
//  ContentView.swift
//  RanaiOS
//
//  Created by Hassaan Ansari  on 05/08/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HomeView()
    }
}

#Preview {
    ContentView()
}
