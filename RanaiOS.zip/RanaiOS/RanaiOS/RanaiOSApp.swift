//
//  RanaiOSApp.swift
//  RanaiOS
//
//  Created by Hassaan Ansari  on 05/08/25.
//

import SwiftUI

@main
struct RanaiOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
